const express = require("express");
const app = express(); // CRIADO UMA INSTÂNCIA DE EXPRESS

const PORT = 33333

app.get("/", function (req, res) {
  res.send("Hello Página HOME")
});
app.listen(PORT, function(){
  resizeBy.send("<h1>Página Sobre</h1>");
});

app.listen(PORT, function () {
  console.log("Rodando na porta: " + PORT);
});