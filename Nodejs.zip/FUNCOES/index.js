// FUNCOES:
// DECLARAÇÃO
function dizOla() {
  console.log('Olá')
}
function olaPessoa(nome) {
  console.log(`Olá, ${nome}`)
}
const nome = 'José'
const idade = 45

function retornaDados() {
  return `Nome: ${nome} - Idade: ${idade}`
}
//IVOCAÇÃO
// dizOla()
// olaPessoa("Rairan");
// console.log(retornaDados());

// FUNÇÕES PERSONALIZADAS VS FUNÇÕES NATIVAS
setInterval(function() {
  console.log('Olá...')
}, 2000) // tempo ms





