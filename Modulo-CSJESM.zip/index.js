function carro() {
  return {
    marca: "Chevrolet",
    modelo: "Camaro",
    ano: 2023,
  };
}

export { carro };

